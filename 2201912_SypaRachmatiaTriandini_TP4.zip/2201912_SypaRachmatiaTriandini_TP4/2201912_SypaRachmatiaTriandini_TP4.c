/* 

NAMA	: SYPA RACHMATIA TRIANDINI
NIM		: 2201912
KELAS	: PENDIDIKAN ILMU KOMPUTER 2B

Buatlah struktur data single linked list untuk menyimpan data Jemaah haji tersebut dengan ketentuan
penyimpanan data dalam linked list adalah:
1. Data yang disimpan adalah data Nama, Gender dan Usia
2. Jemaah haji yang dipanggil untuk melaksanakan ibadah haji berdasarkan urutan list dari first
ke last
3. Setiap data Jemaah dipanggil maka harus dihapus dari linked list
4. Jika ada Jemaah haji baru yang daftar, maka data akan disimpan di dalam list dengan
ketentuan :
	a. Jemaah yang usianya lebih tua akan didahulukan dalam antrian
	b. Jika ada Jemaah yang usianya sama maka urutan akan disesuikan berdasarkan urutan
		pendaftaran, didahulukan yang paling awal daftar
	c. Perempuan dan laki-laki dengan usia sama, maka perempuan akan diprioritaskan
		urutannya.
5. Kode untuk mendaftar adalah 1, Kode untuk memanggil dan menghapus dari daftar adalah 2,
kode untuk mencetak adalah 3 dan kode untuk mengakhiri program adalah 0

*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct data{
	char nama[20];
	char gender[20];
	int usia;
	struct data *next;
} Data; 

Data *head;

Data * CreateData(char nama[20], char gender[20], int usia){
	Data* New = (Data*) malloc(sizeof(Data)); 
    strcpy(New->nama, nama);
    strcpy(New->gender, gender);
    New->usia = usia;
    New->next = NULL;
    
    return New;
}

void tambah(char nama[20], char gender[20], int usia){
	Data *add, *temp;
	add=CreateData(nama, gender, usia);
	if(head==NULL ||(add->usia > (head)->usia) || (add->usia==head->usia && strcmp(add->gender, "Perempuan")==0)){
		add->next=head;
		head=add;
	}else{
		Data *temp=head;
		while(temp->next!=NULL && (temp->next->usia > add->usia || (temp->next->usia==add->usia && strcmp(add->gender, "Laki-laki")==0 
		&& strcmp(temp->next->gender, "Laki-laki")==0) ||(temp->next->usia==add->usia && strcmp(add->gender, "Laki-laki")==0 
		&& strcmp(temp->next->gender, "Perempuan")==0) || (temp->next->usia==add->usia && strcmp(add->gender, "Perempuan")==0 
		&& strcmp(temp->next->gender, "Perempuan")==0))){
			temp=temp->next;
		}
		add->next=temp->next;
		temp->next=add;
	}
}

void hapus(){
	Data *temp, *del;
	del = head;
	temp = head;
	head = temp->next;
	del->next = NULL;
	free(del);
	temp = NULL;
}

void cetakList(){
	if(head == NULL){
		printf("Daftar List kosong\n");
	} else {
		Data *temp = head;
		int i=1;
		while(temp != NULL){
			printf("%s\n", temp->nama);
			printf("%s\n", temp->gender);
			printf("%d\n\n", temp->usia);
			temp = temp->next;
			i++;
		}
	}
}

int main(){
	int pilihan, n, i, usia;
	char nama[20];
	char gender[20];
	
	do{
		scanf("%d", &pilihan);
		switch(pilihan){
			case 0:
				exit(0);
				break;
			case 1:
				scanf("%d", &n);
				for(i=0; i<n; i++){
					scanf("%s", &nama);
					scanf("%s", &gender);
					scanf("%d", &usia);
					tambah(nama, gender, usia);
				}
				break;
			case 2:
				scanf("%d", &n);
				for(i=0; i<n; i++){
					if(head==NULL){
						printf("\nDaftar List kosong");
					} else  {
						hapus();
					}
				}
				break;
			case 3:
				printf("\n");
				cetakList();
				break;
		}
	} while(pilihan!=0);
	
	return 0;
}
